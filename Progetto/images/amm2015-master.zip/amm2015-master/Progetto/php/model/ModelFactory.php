<?php

include_once 'Model.php';
include_once 'UserFactory.php';
include_once 'User.php';
include_once 'Administrator.php';
include_once 'Utente.php';

/**
 * ModelFactory class
 *
 * @author Cesare Piras
 */
class ModelFactory {

    private static $singleton;

    private function __constructor() {
        
    }

    /**
     * Returns a singleton to create models
     * @return \ModelFactory
     */
    public static function instance() {
        if (!isset(self::$singleton)) {
            self::$singleton = new ModelFactory();
        }

        return self::$singleton;
    }

    public function cercaModelPerId($modelid) {
        $models = array();
        $query = "select 
               coltello.id coltello_id,
               coltello.data coltello_data,
               coltello.nome coltello_nome,
               coltello.descrizione coltello_descrizione
               
               from coltello
               
               where coltello.id = ?";
        $mysqli = Db::getInstance()->connectDb();
        if (!isset($mysqli)) {
            error_log("[cercaModelPerId] impossibile inizializzare il database");
            $mysqli->close();
            return $models;
        }

        $stmt = $mysqli->stmt_init();
        $stmt->prepare($query);
        if (!$stmt) {
            error_log("[cercaModelPerId] impossibile" .
                    " inizializzare il prepared statement");
            $mysqli->close();
            return $models;
        }


        if (!$stmt->bind_param('i', $modelid)) {
            error_log("[cercaModelPerId] impossibile" .
                    " effettuare il binding in input");
            $mysqli->close();
            return $models;
        }

        $models = self::caricaModelliDaStmt($stmt);

        if (count($models > 0)) {
            $mysqli->close();
            return $models[0];
        } else {
            $mysqli->close();
            return null;
        }
    }

    public function &getModelsPerAdministrator(Administrator $admin) {
        $models = array();

        $query = "select 
               coltello.id coltello_id,
               coltello.data coltello_data,
               coltello.nome coltello_nome,
               coltello.descrizione coltello_descrizione
               
               from coltello";
        $mysqli = Db::getInstance()->connectDb();
        if (!isset($mysqli)) {
            error_log("[getModelsPerAdministrator] impossibile inizializzare il database");
            $mysqli->close();
            return $models;
        }

        $stmt = $mysqli->stmt_init();
        $stmt->prepare($query);
        if (!$stmt) {
            error_log("[getModelsPerAdministrator] impossibile" .
                    " inizializzare il prepared statement");
            $mysqli->close();
            return null;
        }

        $models = self::caricaModelliDaStmt($stmt);

        $mysqli->close();
        return $models;
    }

    public function &getModelsPerUser(Utente $utente) {
        $models = array();

        $query = "select 
               coltello.id coltello_id,
               coltello.data coltello_data,
               coltello.nome coltello_nome,
               coltello.descrizione coltello_descrizione
               
               from coltello";
        $mysqli = Db::getInstance()->connectDb();
        if (!isset($mysqli)) {
            error_log("[getModelsPerUsers] impossibile inizializzare il database");
            $mysqli->close();
            return $models;
        }

        $stmt = $mysqli->stmt_init();
        $stmt->prepare($query);
        if (!$stmt) {
            error_log("[getModelsPerUser] impossibile" .
                    " inizializzare il prepared statement");
            $mysqli->close();
            return null;
        }

        $models = self::caricaModelliDaStmt($stmt);

        $mysqli->close();
        return $models;
    }

    private function &caricaModelliDaStmt(mysqli_stmt $stmt) {
        $models = array();
        if (!$stmt->execute()) {
            error_log("[caricaModelliDaStmt] impossibile" .
                    " eseguire lo statement");
            $returnNull = null;
            return $returnNull;
        }

        $row = array();
        $bind = $stmt->bind_result(
                $row['coltello_id'], $row['coltello_data'], $row['coltello_nome'], $row['coltello_descrizione']);
        if (!$bind) {
            error_log("[caricaInsegnamentoDaStmt] impossibile" .
                    " effettuare il binding in output");
            return null;
        }

        while ($stmt->fetch()) {
            $models[] = self::creaDaArray($row);
        }

        $stmt->close();

        return $models;
    }

    
    public function creaDaArray($row) {
        $model = new Model();
        $model->setId($row['coltello_id']);
        $model->setNome($row['coltello_nome']);
        $model->setData(new DateTime($row['coltello_data']));
        $model->setDescrizione($row['coltello_descrizione']);
        
        return $model;
    }

    public function salva(Model $model) {
        $query = "update coltello set 
                    id = ?,
                    data = ?,
                    nome = ?,
                    descrizione = ?
                    
                    where coltello.id = ?";
        return $this->modificaDB($model, $query);
    }

    public function nuovo(Model $model) {
        $query = "insert into coltello (id, data, nome, descrizione)
                  values (?, ?, ?, ?)";
        return $this->modificaDB($model, $query);
    }

    public function cancella(Model $model) {
        $query = "delete from coltello where id= ?";
        return $this->modificaDB($model, $query);
    }

    private function modificaDB(Model $model, $query) {
        $mysqli = Db::getInstance()->connectDb();
        if (!isset($mysqli)) {
            error_log("[salva] impossibile inizializzare il database");
            return 0;
        }

        $stmt = $mysqli->stmt_init();

        $stmt->prepare($query);
        if (!$stmt) {
            error_log("[modificaDB] impossibile" .
                    " inizializzare il prepared statement");
            $mysqli->close();
            return 0;
        }

        if (strstr($query, 'delete')) {
            if (!$stmt->bind_param('i', $model->getId())) {
                error_log("[modificaDB] impossibile" .
                        " effettuare il binding in input");
                $mysqli->close();
                return 0;
            }
        } else {
            if (!$stmt->bind_param('isss', $model->getId(), $model->getData()->format('Y-m-d'), $model->getNome(), $model->getDescrizione())) {
                error_log("[modificaDB] impossibile" .
                        " effettuare il binding in input");
                $mysqli->close();
                return 0;
            }
        }

        $mysqli->autocommit(false);

        if (!$stmt->execute()) {
            die($stmt->error);
            error_log("[modificaDB] impossibile" .
                    " eseguire lo statement");
            $mysqli->rollback();
            $mysqli->close();
            return 0;
        }

        $mysqli->commit();
        $mysqli->autocommit(true);
        $mysqli->close();

        return $stmt->affected_rows;
    }

    public function &ricercaModelli($descrizione, $nome) {
        $models_f = array();

        $where = " where lower(coltello.descrizione) like lower(?) and lower(coltello.nome) like lower(?) ";
        $par = array();

        if (isset($descrizione) && isset($nome)) {
            $where = " where lower(coltello.descrizione) like lower(?) and lower(coltello.nome) like lower(?) ";
            $bind = "ss";
            $par[] = "%" . $descrizione . "%";
            $par[] = "%" . $nome . "%";
        } else
        if (isset($descrizione)) {
            $where = " where lower(coltello.descrizione) like lower(?) ";
            $bind = "s";
            $par[] = "%" . $descrizione . "%";
        } else
        if (isset($nome)) {
            $where = " where lower(coltello.nome) like lower(?) ";
            $bind = "s";
            $par[] = "%" . $nome . "%";
        }

        $query = "select 
                  coltello.id coltello_nome,
                  coltello.data coltello_data,
                  coltello.nome coltello_nome,
                  coltello.descrizione coltello_descrizione

                  from coltello 
                  " . $where;

        $mysqli = Db::getInstance()->connectDb();
        if (!isset($mysqli)) {
            error_log("[ricercaEsami] impossibile inizializzare il database");
            $mysqli->close();
            return $models_f;
        }

        $stmt = $mysqli->stmt_init();
        $stmt->prepare($query);
        if (!$stmt) {
            error_log("[ricercaEsami] impossibile" .
                    " inizializzare il prepared statement");
            $mysqli->close();
            return $models_f;
        }

        switch (count($par)) {
            case 1:
                if (!$stmt->bind_param($bind, $par[0])) {
                    error_log("[ricercaModelli] impossibile" .
                            " effettuare il binding in input");
                    $mysqli->close();
                    return $models_f;
                }
                break;
            case 2:
                if (!$stmt->bind_param($bind, $par[0], $par[1])) {
                    error_log("[ricercaModelli] impossibile" .
                            " effettuare il binding in input");
                    $mysqli->close();
                    return $models_f;
                }
                break;
        }

        $models_f = self::caricaModelliDaStmt($stmt);
        $mysqli->close();
        return $models_f;
    }

}

?>
