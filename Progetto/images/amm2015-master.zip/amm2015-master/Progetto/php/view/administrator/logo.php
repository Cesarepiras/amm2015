<p>Pagina Admin - <?= $user->getNome().' '.$user->getCognome() ?></p>
<p class="logout">
    <a href="administrator?cmd=logout">Logout</a>
</p>
