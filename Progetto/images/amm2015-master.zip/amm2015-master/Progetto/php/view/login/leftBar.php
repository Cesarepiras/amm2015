<h2 class="icon-title">Navigation</h2>
<ul>
    <li><a href="login">Home</a></li>
</ul>
