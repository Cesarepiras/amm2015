<ul>
    <li><a class="current_page_item" href="login">Home</a></li>
</ul>
