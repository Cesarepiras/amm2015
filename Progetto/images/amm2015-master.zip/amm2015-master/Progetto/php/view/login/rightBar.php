<h2  class="icon-title" id="help">Benvenuto in TCE</h2>
<p>
    In questa pagina puoi eseguire il login come Admin o user.
</p>
<p>
    Queste sono le categorie di utenti attualmente disponibili:
    <ul>
            <li>
                <strong>Admin</strong>: username: cesare, password: piras
            </li>
            <li>
                <strong>User</strong>: username: user, password: user
            </li>
        </ul>
</p>
