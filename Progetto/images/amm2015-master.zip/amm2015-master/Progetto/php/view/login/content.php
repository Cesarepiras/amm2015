<div class="input-form">
    <h3>Login</h3>

    <form method="post" action="login">
        <input type="hidden" name="cmd" value="login"/>
        <label for="user">Username</label>
        <input type="text" name="user" id="user"/>
        <br>
        <label for="password">Password</label>
        <input type="password" name="password" id="password"/> 
        <br/>
        <input type="submit" value="Login"/>
       

    </form>
</div>
