<p>Pagina Utente - <?= $user->getUsername() ?></p>
<p class="logout">
    <a href="user?cmd=logout">Logout</a>
</p>
